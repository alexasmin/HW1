function [ theta ] = cheb2Dfirst( nodes, degree, x, y )
%2Dfirstrow and cloumn cheb thetas
j=nodes;
d=degree;

zahlerele=[];
c=0;

for i=1:j;
 for m=1:j;
 zahlerele(1+c)= y(m,i)*chebyshevT(d, x(m));   %calculate the numerator 
 c=c+1;
 end

end

zahler=sum(zahlerele); 

nennerele=[];

for m=1:j;
    nennerele(1+c)= chebyshevT(d, x(m))*chebyshevT(d, x(m)); %calculate the denominator
    c=c+1;
end

nenner=sum(nennerele)*2;

theta=zahler/nenner;


end

