function [ theta ] = cheb2D( nodes, degree1, degree2, x, y )
%2D cheb thetas
j=nodes;
d1=degree1;
d2=degree2;

zahlerele=[];
c=0;

for i=1:j;
 for m=1:j;
 zahlerele(1+c)= y(m,i)*chebyshevT(d1, x(i))*chebyshevT(d2, x(m)); %numerator
 c=c+1;
 end

end

zahler=sum(zahlerele); 

nennerele=[];

for i=1:j;      %denominator
  for m=1:j;
    nennerele(1+c)= chebyshevT(d1, x(i))*chebyshevT(d1, x(i))*chebyshevT(d2, x(m))*chebyshevT(d2, x(m));
    c=c+1;
  end
end

nenner=sum(nennerele);

theta=zahler/nenner;


end

