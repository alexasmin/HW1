%HW2 quant macro Alexander Wurdinger
clear;clc;
%% Q 1
syms x
f=x^0.321;

T1=taylor(f,x,1, 'order', 2);
T2=taylor(f,x,1, 'order', 3);
T5=taylor(f,x,1, 'order', 6);
T20=taylor(f,x,1, 'order', 21); 


%%
fplot([ f T1 T2 T5 T20])
xlim([0 4])
ylim([-2 7])

legend('f',...
       'first order approx',...
       'second order approx',...
       'fifth order approx',...
       'approx of order 20','location','best')
title('Taylor Series Expansion of f(x)=x^(0.321)')

%% Q2
clear;
syms x
r=(x+abs(x))/2;
rr=x;   %as the taylor series is approxed around x=1, i just use the ramp function for x>0

r1=taylor(rr,x,2, 'order', 2);
r2=taylor(rr,x,2, 'order', 3);      
r5=taylor(rr,x,2, 'order', 6);
r20=taylor(rr,x,2, 'order', 21); 


%%
fplot([ r r1 r2 r5 r20])
xlim([-2 6])
ylim([-2 7])

legend('r',...
       'first order approx',...
       'second order approx',...
       'fifth order approx',...
       'approx of order 20','location','best')
title('Taylor Series Expansion of ramp function')


%% Q3 exponent
clear;
 m=[3 5 10];
    a=-1; b=1;  %start and finish


    x=a:0.3:b;      %interpolation nodes
    y=exp(1./x); %function

   pp3=polyfit(x,y,m(1));
   pp5=polyfit(x,y,m(2));   %polyfit fittet polynomials of n order through the interpolation nodes x and 
   pp10=polyfit(x,y,m(3));  %returns the coeficions which are used to fill in the general polynomials below
   
   exp0=@(x) exp(1./x);
   exp3=@(x) pp3(4)+pp3(3)*x+pp3(2)*x.^2+pp3(1)*x.^3;
   exp5=@(x) pp5(6)+pp5(5)*x+pp5(4)*x.^2+pp5(3)*x.^3+pp5(2)*x.^4+pp5(1)*x.^5;
   exp10=@(x) pp10(11)+pp10(10)*x+pp10(9)*x.^2+pp10(8)*x.^3+pp10(7)*x.^4+pp10(6)*x.^5+pp10(5)*x.^6+pp10(4)*x.^7+pp10(3)*x.^8+pp10(2)*x.^9+pp10(1)*x.^10;
   
   
   fplot([exp0 ])
   hold on
   fplot([exp3 ])
   hold on
   fplot([exp5 ])
   hold on
   fplot([exp10 ])
   xlim([-1 1])
   ylim([-100 200])
   legend('e^1/x',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
%%
error3=@(x) exp0(x)-exp3(x);
error5=@(x) exp0(x)-exp5(x);
error10=@(x) exp0(x)-exp10(x);
%%
fplot(error3)
hold on              
fplot(error5)          
hold on 
fplot(error10)
xlim([-1 1])
ylim([-100 100])
legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')
%% create chebishev nodes
n=11;
chevn1=zeros(1,n);

for j=1:n
    b=(2*j-1)/(2*n);
   chevn1(j)=cos(b*pi);
end

chevn=flip(chevn1);

%% Q3 cheb nodes
 m=[3 5 10];
    a=-1; b=1;  %start and finish

    chevex=chevn;
    chevex(6)=0.2;
    x=chevex;      %nodes
    y=exp(1./x); %function

   pp3=polyfit(x,y,m(1));
   pp5=polyfit(x,y,m(2));   %same as befor
   pp10=polyfit(x,y,m(3));
   
   exp0=@(x) exp(1./x);
   exp3=@(x) pp3(4)+pp3(3)*x+pp3(2)*x.^2+pp3(1)*x.^3;
   exp5=@(x) pp5(6)+pp5(5)*x+pp5(4)*x.^2+pp5(3)*x.^3+pp5(2)*x.^4+pp5(1)*x.^5;
   exp10=@(x) pp10(11)+pp10(10)*x+pp10(9)*x.^2+pp10(8)*x.^3+pp10(7)*x.^4+pp10(6)*x.^5+pp10(5)*x.^6+pp10(4)*x.^7+pp10(3)*x.^8+pp10(2)*x.^9+pp10(1)*x.^10;
   
   
   fplot([exp0 ])
   hold on
   fplot([exp3 ])
   hold on
   fplot([exp5 ])
   hold on
   fplot([exp10 ])
   xlim([-1 1])
   ylim([-100 200])
   legend('e^1/x',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
%%
error3=@(x) exp0(x)-exp3(x);
error5=@(x) exp0(x)-exp5(x);
error10=@(x) exp0(x)-exp10(x);

%%
fplot(error3)
hold on              
fplot(error5)
hold on 
fplot(error10)       
xlim([-1 1])
ylim([-100 100])
legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')
%% Cheb exp 
n=11;
d=10;
thetas=ones(d+1,1);

thetas(1)=sum(y)/11;

for j=1:d;

thetas(j+1)=cheb(n, j, x, y);  %using the self programmed function cheb that fits a cheb polynomial through 
                               %the cheb nodes, where the coefficents are
                               %basically obtained via OLS
end

%%
expC3=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x);
expC5=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x)+thetas(5)*(8*x.^4 - 8*x.^2 + 1)+thetas(6)*(16*x.^5 - 20*x.^3 + 5*x);
expC10=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x)+thetas(5)*(8*x.^4 - 8*x.^2 + 1)+thetas(6)*(16*x.^5 - 20*x.^3 + 5*x)+thetas(7)*(32*x.^6 - 48*x.^4 + 18*x.^2 - 1)+thetas(8)*(64*x.^7 - 112*x.^5 + 56*x.^3 - 7*x)+thetas(9)*(128*x.^8 - 256*x.^6 + 160*x.^4 - 32*x.^2 + 1)+thetas(10)*(256*x.^9 - 576*x.^7 + 432*x.^5 - 120*x.^3 + 9*x)+thetas(11)*(512*x.^10 - 1280*x.^8 + 1120*x.^6 - 400*x.^4 + 50*x.^2 - 1);

%%
fplot(exp0)
hold on
fplot(expC3)
hold on 
fplot(expC5)
hold on 
fplot(expC10)
xlim([-1 1])
ylim([-100 200])
legend('e^1/x',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
%%
error3=@(x) exp0(x)-expC3(x);
error5=@(x) exp0(x)-expC5(x);
error10=@(x) exp0(x)-expC10(x);
%%
fplot(error3)
hold on              
fplot(error5)
hold on 
fplot(error10)
xlim([-1 1])
ylim([-100 100])
legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')
%% runge 
%same procedure as before for the runge function 
clear;
 m=[3 5 10];
    
    a=-1; b=1;     %start and finish

    x=a:0.2:b;      %domain
    y=1./(1+25*x.^2);  %function

    pp3=polyfit(x,y,m(1));
    pp5=polyfit(x,y,m(2));
    pp10=polyfit(x,y,m(3));
    
    rung=@(x) 1./(1+25*x.^2);
    rung3=@(x) pp3(4)+pp3(3)*x+pp3(2)*x.^2+pp3(1)*x.^3;
    rung5=@(x) pp5(6)+pp5(5)*x+pp5(4)*x.^2+pp5(3)*x.^3+pp5(2)*x.^4+pp5(1)*x.^5;
    rung10=@(x) pp10(11)+pp10(10)*x+pp10(9)*x.^2+pp10(8)*x.^3+pp10(7)*x.^4+pp10(6)*x.^5+pp10(5)*x.^6+pp10(4)*x.^7+pp10(3)*x.^8+pp10(2)*x.^9+pp10(1)*x.^10;
    
   fplot([rung ])
   hold on
   fplot([rung3 ])
   hold on
   fplot([rung5 ])
   hold on
   fplot([rung10 ])
   xlim([-1 1])
   ylim([-0.5 1])
   legend('runge',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
%%
error3=@(x) rung(x)-rung3(x);
error5=@(x) rung(x)-rung5(x);
error10=@(x) rung(x)-rung10(x);

%%
fplot(error3)
hold on              
fplot(error5)
hold on 
fplot(error10)
xlim([-1 1])
ylim([-0.5 0.5])
legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')
%%
n=11;
chevn1=zeros(1,n);

for j=1:n
    b=(2*j-1)/(2*n);
   chevn1(j)=cos(b*pi);
end

chevn=flip(chevn1);      

%% runge cheb nodes
 m=[3 5 10];
    
    a=-1; b=1;     %start and finish

    x=chevn;      %domain
    y=1./(1+25*x.^2);  %function

    pp3=polyfit(x,y,m(1));
    pp5=polyfit(x,y,m(2));
    pp10=polyfit(x,y,m(3));
    
    rung=@(x) 1./(1+25*x.^2);
    rung3=@(x) pp3(4)+pp3(3)*x+pp3(2)*x.^2+pp3(1)*x.^3;
    rung5=@(x) pp5(6)+pp5(5)*x+pp5(4)*x.^2+pp5(3)*x.^3+pp5(2)*x.^4+pp5(1)*x.^5;
    rung10=@(x) pp10(11)+pp10(10)*x+pp10(9)*x.^2+pp10(8)*x.^3+pp10(7)*x.^4+pp10(6)*x.^5+pp10(5)*x.^6+pp10(4)*x.^7+pp10(3)*x.^8+pp10(2)*x.^9+pp10(1)*x.^10;
    
   fplot([rung ])
   hold on
   fplot([rung3 ])
   hold on
   fplot([rung5 ])
   hold on
   fplot([rung10 ])
   xlim([-1 1])
   ylim([-1 1])
   legend('runge',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')

%%
error3=@(x) rung(x)-rung3(x);
error5=@(x) rung(x)-rung5(x);
error10=@(x) rung(x)-rung10(x);

%%
fplot(error3)
hold on              
fplot(error5)
hold on 
fplot(error10)
xlim([-1 1])
ylim([-0.5 0.5])
legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')
%% Cheb rung
n=11;
d=10;
thetas=ones(d+1,1);

thetas(1)=sum(y)/11;

for j=1:d;

thetas(j+1)=cheb(n, j, x, y);

end

%%
rungC3=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x);
rungC5=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x)+thetas(5)*(8*x.^4 - 8*x.^2 + 1)+thetas(6)*(16*x.^5 - 20*x.^3 + 5*x);
rungC10=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x)+thetas(5)*(8*x.^4 - 8*x.^2 + 1)+thetas(6)*(16*x.^5 - 20*x.^3 + 5*x)+thetas(7)*(32*x.^6 - 48*x.^4 + 18*x.^2 - 1)+thetas(8)*(64*x.^7 - 112*x.^5 + 56*x.^3 - 7*x)+thetas(9)*(128*x.^8 - 256*x.^6 + 160*x.^4 - 32*x.^2 + 1)+thetas(10)*(256*x.^9 - 576*x.^7 + 432*x.^5 - 120*x.^3 + 9*x)+thetas(11)*(512*x.^10 - 1280*x.^8 + 1120*x.^6 - 400*x.^4 + 50*x.^2 - 1);

%%
fplot(rung)
hold on
fplot(rungC3)
hold on 
fplot(rungC5)
hold on 
fplot(rungC10)
xlim([-1 1])
ylim([-1 1])
legend('runge',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
%%
error3=@(x) rung(x)-rungC3(x);
error5=@(x) rung(x)-rungC5(x);
error10=@(x) rung(x)-rungC10(x);
%%
fplot(error3)
hold on              
fplot(error5)
hold on 
fplot(error10)
xlim([-1 1])
ylim([-0.5 0.5])
legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')
%% ramp
clear;
m=[3 5 10];
    a=-1; b=1;  %start and finish
y=[];
x=a:0.2:b;   %domain
for i=1:11
if x(i)<0 %function
    y(i)=0;
else 
    y(i)=x(i); 
end
end 

pp3=polyfit(x,y,m(1));
pp5=polyfit(x,y,m(2));
pp10=polyfit(x,y,m(3));

ramp=@(x) (x+abs(x))./2;
ramp3=@(x) pp3(4)+pp3(3)*x+pp3(2)*x.^2+pp3(1)*x.^3;
ramp5=@(x) pp5(6)+pp5(5)*x+pp5(4)*x.^2+pp5(3)*x.^3+pp5(2)*x.^4+pp5(1)*x.^5;
ramp10=@(x) pp10(11)+pp10(10)*x+pp10(9)*x.^2+pp10(8)*x.^3+pp10(7)*x.^4+pp10(6)*x.^5+pp10(5)*x.^6+pp10(4)*x.^7+pp10(3)*x.^8+pp10(2)*x.^9+pp10(1)*x.^10;
   
   fplot([ramp ])
   hold on
   fplot([ramp3 ])
   hold on
   fplot([ramp5 ])
   hold on
   fplot([ramp10 ])
   xlim([-1 1])
   ylim([-0.5 1])
   grid on
   legend('ramp',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
 
%%
error3=@(x) ramp(x)-ramp3(x);
error5=@(x) ramp(x)-ramp5(x);
error10=@(x) ramp(x)-ramp10(x);

%%
fplot(error3)
hold on              %smth doesnt work with the plot, the functions are correct
fplot(error5)
hold on 
fplot(error10)
xlim([-1 1])
ylim([-0.5 0.5])
legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')

%%
n=11;
chevn1=zeros(1,n);

for j=1:n
    b=(2*j-1)/(2*n);
   chevn1(j)=cos(b*pi);
end

chevn=flip(chevn1);


%% ramp
m=[3 5 10];
    a=-1; b=1;  %start and finish
y=[];
x=chevn;   %domain
for i=1:11
if x(i)<0 %function
    y(i)=0;
else 
    y(i)=x(i); 
end
end 

pp3=polyfit(x,y,m(1));
pp5=polyfit(x,y,m(2));
pp10=polyfit(x,y,m(3));

ramp=@(x) (x+abs(x))./2;
ramp3=@(x) pp3(4)+pp3(3)*x+pp3(2)*x.^2+pp3(1)*x.^3;
ramp5=@(x) pp5(6)+pp5(5)*x+pp5(4)*x.^2+pp5(3)*x.^3+pp5(2)*x.^4+pp5(1)*x.^5;
ramp10=@(x) pp10(11)+pp10(10)*x+pp10(9)*x.^2+pp10(8)*x.^3+pp10(7)*x.^4+pp10(6)*x.^5+pp10(5)*x.^6+pp10(4)*x.^7+pp10(3)*x.^8+pp10(2)*x.^9+pp10(1)*x.^10;
   
   fplot([ramp ])
   hold on
   fplot([ramp3 ])
   hold on
   fplot([ramp5 ])
   hold on
   fplot([ramp10 ])
   xlim([-1 1])
   ylim([-0.5 1])
   grid on
   legend('ramp',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
 
%%
error3=@(x) ramp(x)-ramp3(x);
error5=@(x) ramp(x)-ramp5(x);
error10=@(x) ramp(x)-ramp10(x);

%%
fplot(error3)
hold on              %smth doesnt work with the plot, the functions are correct
fplot(error5)
hold on 
fplot(error10)
xlim([-1 1])
ylim([-0.5 0.5])

legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')


%% Cheb ramp

n=11;
d=10;
thetas=ones(d+1,1);

thetas(1)=sum(y)/11;

for j=1:d;

thetas(j+1)=cheb(n, j, x, y);

end

%%
rampC3=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x);
rampC5=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x)+thetas(5)*(8*x.^4 - 8*x.^2 + 1)+thetas(6)*(16*x.^5 - 20*x.^3 + 5*x);
rampC10=@(x) thetas(1)+thetas(2)*x+thetas(3)*(2*x.^2-1)+thetas(4)*(4*x.^3-3*x)+thetas(5)*(8*x.^4 - 8*x.^2 + 1)+thetas(6)*(16*x.^5 - 20*x.^3 + 5*x)+thetas(7)*(32*x.^6 - 48*x.^4 + 18*x.^2 - 1)+thetas(8)*(64*x.^7 - 112*x.^5 + 56*x.^3 - 7*x)+thetas(9)*(128*x.^8 - 256*x.^6 + 160*x.^4 - 32*x.^2 + 1)+thetas(10)*(256*x.^9 - 576*x.^7 + 432*x.^5 - 120*x.^3 + 9*x)+thetas(11)*(512*x.^10 - 1280*x.^8 + 1120*x.^6 - 400*x.^4 + 50*x.^2 - 1);

%%
fplot(ramp)
hold on 
fplot(rampC3)
hold on 
fplot(rampC5)
hold on 
fplot(rampC10)
xlim([-1 1])
ylim([-0.5 1])
legend('ramp',...
       'cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
%%
error3=@(x) ramp(x)-rampC3(x);
error5=@(x) ramp(x)-rampC5(x);
error10=@(x) ramp(x)-rampC10(x);

%%
fplot(error3)
hold on              
fplot(error5)
hold on 
fplot(error10)
xlim([-1 1])
ylim([-0.5 0.5])

legend('cubic',...
       'monomial order 5',...
       'monomial order 10',...
       'location','best')
   title('Approximation error')

%% %%%%%%%%%%%%% PART 2 %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;clc;
n=5;
chevn1=zeros(1,n);    %first chebyshev nodes
a=0; b=10;

for j=1:n
    c=(2*j-1)/(2*n);
   chevn1(j)=cos(c*pi);
end

chevn2=(a+b)/2+((b-a)/2)*chevn1;
chevn=flip(chevn2);


%%
m=5; 
alpha=0.5;
sig=0.25;
k=chevn;
h=chevn;

f=@(k,h) ((1-alpha)*k.^((sig-1)/sig)+alpha*h.^((sig-1)/sig)).^(sig/(sig-1));  %CES production function

fkh=zeros(m);

for i=1:m
    for j=1:m     %eveluat the function at each node (two dimensional)

        fkh(i,j)=((1-alpha)*k(i).^((sig-1)/sig)+alpha*h(j).^((sig-1)/sig)).^(sig/(sig-1));
    end
end


%%
thetas=zeros(m,m);   %calculate all dxd thetas with the self programmed function cheb2D
for v=1:m
    for w=1:m
        thetas(v,w)=cheb2D(m, v, w, k, fkh);
    end
end
%%
vx=chebyshev_basis_x(m);
vy=chebyshev_basis_y(m);
vv=vx'*vy;
polys=thetas.*vv;   %create function containing all cross products of the usual 
                    %cheb polynomials and multiply the corresponding thetas
                    

syms x y
pol=polys(1,1);
for t=2:m
        pol=pol+polys(1,m);
end

for s=2:m
    pol=pol+polys(s,1);
end
        
for p=2:m
    for q=2:m
        pol=pol+polys(p,q);
    end
end
%%
polf=@(x,y) pol(1);

%%
x = 0:0.1:10;  % define range and mesh of x and y which will be shown in figure
y = 0:0.1:10;
[X, Y] = meshgrid(x, y);
surf(X, Y, f(X,Y));
figure;
contourf(X, Y, f(X,Y));

%%
%Isoquants plot
alpha=0.5;sigma=0.25;m=20;
%Here, we are considering the maximum amount of k and h which can be used.
ces_max=((1-alpha)*10.^((sigma-1)/sigma)+alpha*10.^((sigma-1)/sigma)).^(sigma/(sigma-1));

syms k
h1=((0.5.^3)./(2-k.^3)).^(1/3);
h2=((1.^3)./(2-k.^3)).^(1/3);
h3=((2.5.^3)./(2-k.^3)).^(1/3);
h4=((5.^3)./(2-k.^3)).^(1/3);
h5=((7.5.^3)./(2-k.^3)).^(1/3);
h6=((9.^3)./(2-k.^3)).^(1/3);
h7=((9.5.^3)./(2-k.^3)).^(1/3);
k1=[1:10];
h_eval1=zeros(1,10);
for i=1:10
h_eval1(i)=subs(h1,k,k1(i));
end
h_eval2=zeros(1,10);
for i=1:10
h_eval2(i)=subs(h2,k,k1(i));
end
h_eval3=zeros(1,10);
for i=1:10
    h_eval3(i)=subs(h3,k,k1(i));
end
h_eval4=zeros(1,10);
for i=1:10
    h_eval4(i)=subs(h4,k,k1(i));
end
h_eval5=zeros(1,10);
for i=1:10
    h_eval5(i)=subs(h5,k,k1(i));
end
h_eval6=zeros(1,10);
for i=1:10
    h_eval6(i)=subs(h6,k,k1(i));
end
h_eval7=zeros(1,10);
for i=1:10
    h_eval7(i)=subs(h7,k,k1(i));
end

 plot(h_eval1,k1)
 hold on
 plot(h_eval2,k1)
 hold on
 plot(h_eval3,k1)
hold on 
 plot(h_eval4,k1)
 hold on
 plot(h_eval5,k1)
 hold on
 plot(h_eval6,k1)
hold on
plot(h_eval7,k1)
title('Isoquant graph')
legend('Isoquant percentil 5','Isoquant percentil 10','Isoquant percentil 25','Isoquant percentil 50','Isoquant percentil 75','Isoquant percentil 90','Isoquant percentil 95')


