clc;clear;
%%
G=xlsread('GDP');
IN=xlsread('Income');
INcorp=xlsread('Incomecorp');
GDPdefl=xlsread('GDPdeflator');
Assetdefl=xlsread('Assetdeflator');
Fixass=xlsread('fixedassets');
%%
GDP=G(1,:);
TS=IN(19,3:end)-IN(20,3:end);
NMI=IN(9,3:end);
IPP=G(12,:);
CE=IN(2,3:end);
CEc=INcorp(4,:);%+INcorp(20,:);
TSc=INcorp(9,:);
bus=INcorp(3,:);
Gdef=GDPdefl(1,:);
Adef=Assetdefl(2,:);
Knom=Fixass(2,:);
%NMIc=INcorp(23,:);
time=[1929:2018];
%% 1
A=TS./GDP;
B=NMI./GDP;
C=IPP./GDP;

plot(time,A)
hold on 
plot(time,B)
hold on
plot(time,C)


%% 2
LS0=CE./GDP;          
LS1=CE./(GDP-TS);     %hump shape
LS2=CE./(GDP-TS-NMI); %hump shap 

plot(time,LS0)
hold on 
plot(time,LS1)
hold on
plot(time,LS2)

%% SNA93 proxy
LS0=CE./(GDP-IPP);          
LS1=CE./(GDP-IPP-TS);     %
LS2=CE./(GDP-IPP-TS-NMI); % 

plot(time,LS0)
hold on 
plot(time,LS1)
hold on
plot(time,LS2)

%% 3
GDPc=GDP(18:end);
time2=[1947:2019];


LS0c=CEc./bus;          
LS1c=CEc./(bus-TSc);     
LS2c=CEc./(bus-TSc-NMI(18:end));  

plot(time2,LS0c)
hold on 
plot(time2,LS1c)
hold on                   %not hump shaped but rather gradual decrease 
%plot(time2,LS2c)         %NMI cannot exist in the corparate sector 

%% SNA93 proxy
%LS0c=CEc./(bus-IPPc);          
%LS1c=CEc./(bus-IPPc-TSc);     %
%LS2c=CEc./(bus-IPPc-TSc-NMI(18:end)); %

%plot(time2,LS0c)
%hold on 
%plot(time2,LS1c)
%hold on
%plot(time2,LS2c)



%% 4 run part 2 SNA 2018 first for SNA 2018 estimates, or run SNA 1993 first for SNA 93 estimates
GDPnom=Gdef*GDP(84)/100;
capin0=GDPnom.*(1-LS0);   
capin1=GDPnom.*(1-LS1);
capin2=GDPnom.*(1-LS2);


%%
K=Adef*Knom(84)/100;

R0=capin0./K;
R1=capin1./K;
R2=capin2./K;


plot(time,R0)
hold on 
plot(time,R1)
hold on 
plot(time,R2)

